

class Item {

  //Variables Privadas
  int _idItem;
  String _nombre;
  String _descripcion;

  //Constructor

  Item(this._idItem, this._nombre, this._descripcion);

  //Get and set de _descripcion

  String get descripcion => _descripcion;

  set descripcion(String value) {
    _descripcion = value;
  }

  //Get and set de _nombre

  String get nombre => _nombre;

  set nombre(String value) {
    _nombre = value;
  }

  //Get and set de _id_item

  int get idItem => _idItem;

  set idItem(int value) {
    _idItem = value;
  }





}