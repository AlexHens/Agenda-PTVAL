

import 'platos.dart';

class Menus {

  //Variables Privadas
  int _idMenu;
  String _tipo;
  List<Platos> _platos;

  //Constructor

  Menus(this._idMenu, this._tipo, this._platos);

  //Get and set de _platos

  List<Platos> getAlumno(){
    return _platos;
  }

  void setAlumno(List<Platos> p){
    _platos = p;
  }

  //Get and set de _tipo

  String get tipo => _tipo;

  set tipo(String value) {
    _tipo = value;
  }

  //Get and set de _id_menu

  int get idMenu => _idMenu;

  set idMenu(int value) {
    _idMenu = value;
  }


}