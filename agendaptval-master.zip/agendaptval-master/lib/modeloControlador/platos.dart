


class Platos {

  //Variables Privadas
  int _idPlato;
  String _tipo;
  String _nombre;
  List<String> _ingredientes;

  //Constructor

  Platos(this._idPlato, this._tipo, this._nombre, this._ingredientes);

  //Get and set de _ingredientes

  List<String> get ingredientes => _ingredientes;

  set ingredientes(List<String> value) {
    _ingredientes = value;
  }

  //Get and set de _nombre

  String get nombre => _nombre;

  set nombre(String value) {
    _nombre = value;
  }

  //Get and set de _tipo

  String get tipo => _tipo;

  set tipo(String value) {
    _tipo = value;
  }

  //Get and set de _id_plato

  int get idPlato => _idPlato;

  set idPlato(int value) {
    _idPlato = value;
  }




}