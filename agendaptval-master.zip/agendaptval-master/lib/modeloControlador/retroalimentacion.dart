


import 'tarea.dart';

class Retroalimentacion {

  //Variables Privadas
  int _idRetroalimentacion;
  String _descripcion;
  int _calificacion;
  Tarea _tarea;

  //Constructor
  Retroalimentacion(this._idRetroalimentacion, this._descripcion, this._calificacion,
      this._tarea);

  //Get and set de _tarea

  Tarea getTarea(){
    return _tarea;
  }

  void setTarea(Tarea t){
    _tarea = t;
  }

  //Get and set de _calificacion

  int get calificacion => _calificacion;

  set calificacion(int value) {
    _calificacion = value;
  }

  //Get and set de _descripcion

  String get descripcion => _descripcion;

  set descripcion(String value) {
    _descripcion = value;
  }

  //Get and set de _id_retroalimentacion

  int get idRetroalimentacio => _idRetroalimentacion;

  set idRetroalimentacio(int value) {
    _idRetroalimentacion = value;
  }

}