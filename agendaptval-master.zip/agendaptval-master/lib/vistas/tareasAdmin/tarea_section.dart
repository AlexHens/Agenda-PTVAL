import 'package:agendaptval/modeloControlador/tarea.dart';

import '../../flutter_flow/flutter_flow_icon_button.dart';
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import '../../flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


import '../../main.dart';
import 'crear_tarea_admin.dart';
import 'descripcion_tarea_admin.dart';
import 'editar_tarea_admin.dart';

class TareaSection extends StatefulWidget{

  String _nombre;
  int _idTarea;

  TareaSection(this._nombre, this._idTarea);


  @override
  _TareaSectionState createState() =>_TareaSectionState(this._nombre, this._idTarea);
}

class _TareaSectionState extends State<TareaSection>{
  String _nombre;
  int _idTarea;
  bool _loadingButton1 = false;

  _TareaSectionState(this._nombre, this._idTarea);

  @override
  Widget build(BuildContext context) {
    return   Row(
            mainAxisSize: MainAxisSize.max,
            children: [
               Padding(
                   padding: EdgeInsetsDirectional.fromSTEB(25, 15, 0, 0),
                   child:
                   Container(
                     width: 165.5,
                     height: 60,
                     decoration: BoxDecoration(
                       color: Colors.white,
                     ),
                     child: ListView(

                         children: [
                         Row(
                         crossAxisAlignment: CrossAxisAlignment.center,
                         mainAxisSize: MainAxisSize.max,
                         mainAxisAlignment: MainAxisAlignment.start,

                         children: [

                   InkWell(
                   onTap: () async {
                     await Navigator.push(
                     context,
                     MaterialPageRoute(
                       builder: (context) => DescripcionTareaAdminWidget(this._idTarea),
                     ),
                    );
                  },
                  child: Text(
                   this._nombre,
                              style: FlutterFlowTheme.bodyText1,
                   ),
                  )
                 ]
               )
              ]
             )
            )
          ),


          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0, 15, 0, 0),
            child:
            Container(
            width: 185.5,
            height: 60,
            decoration: BoxDecoration(
            color: Colors.white,
            ),
            child: ListView(

            children: [
            Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
            FFButtonWidget(
              onPressed: () async {
                setState(() => _loadingButton1 = true);
                try {
                  // await Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //     builder: (context) => EditarTareaAdminWidget(this._idTarea),
                  //   ),
                  // );
                } finally {
                  setState(() => _loadingButton1 = false);
                }
              },
              text: 'Editar\n',
              options: FFButtonOptions(
                width: 90,
                height: 40,
                color: Color(0xFFC2A5C0),
                textStyle: FlutterFlowTheme.bodyText1,
                borderSide: BorderSide(
                  color: Color(0xFF0D0D0D),
                  width: 1,
                ),
                borderRadius: 12,
              ),
              loading: _loadingButton1,
            ),
            ]
          ),
          ]
          )
          )

          )
        ],
      );


  }

}